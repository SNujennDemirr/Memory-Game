import React, { useState } from 'react';
import Card from './Card';

// Resimleri doğrudan import ediyoruz
import img1 from '../assets//1.jpeg';
import img2 from '../assets//2.jpeg';
import img3 from '../assets//3.jpeg';
import img4 from '../assets//4.jpeg';
import img5 from '../assets//5.jpeg';
import img6 from '../assets//6.jpeg';
interface CardData {
  id: number;
  image: string;
}

const createCardArray = (): CardData[] => {

  const images = [img1, img2, img3, img4, img5, img6];

  const cards = images.flatMap((image, index) =>
    Array(2).fill(null).map((_, cardIndex) => ({
      id: index * 2 + cardIndex,
      image,
    }))
  );
  
  return shuffleArray(cards);
};

const shuffleArray = (array: any[]) => {
  let currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  return array;
};

const Board: React.FC = () => {
  const [cards, setCards] = useState<CardData[]>(createCardArray());
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedCards, setMatchedCards] = useState<number[]>([]);

  const handleCardClick = (id: number) => {
    if (flippedCards.length === 2 || flippedCards.includes(id) || matchedCards.includes(id)) {
      return;
    }

    const newFlippedCards = [...flippedCards, id];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      const [firstId, secondId] = newFlippedCards;
      if (cards[firstId].image === cards[secondId].image) {
        setMatchedCards([...matchedCards, firstId, secondId]);
      }
      setTimeout(() => setFlippedCards([]), 1000);
    }
  };

  return (
    <div className="board">
      {cards.map(card => (
        <Card
          key={card.id}
          id={card.id}
          image={card.image}
          isFlipped={flippedCards.includes(card.id) || matchedCards.includes(card.id)}
          onClick={handleCardClick}
        />
      ))}
    </div>
  );
};

export default Board;
